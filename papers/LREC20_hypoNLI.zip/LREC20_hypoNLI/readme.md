The scores reported in the paper correspond to (lambda=0.7) for MultiNLI and (lambda=0.8) for SNLI respectively.
